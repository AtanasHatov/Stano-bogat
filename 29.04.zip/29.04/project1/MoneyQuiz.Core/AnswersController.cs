﻿using Microsoft.EntityFrameworkCore;
using MoneyQuiz.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.Core
{
    public class AnswersController
    {
        GameDBContext gameDBContext = new GameDBContext();

        public async Task UpdateAnswear(int id, string answeratext, bool isCorrect, int questionid)
        {
            var answer=await gameDBContext.Answers.FirstOrDefaultAsync(a=>a.Id == id);
            answer.answer_text = answeratext;
            answer.is_correct = isCorrect;
            answer.QuestionsID = questionid;
            await gameDBContext.SaveChangesAsync();
        }
    }
}
