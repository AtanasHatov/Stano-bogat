﻿using Microsoft.EntityFrameworkCore;
using MoneyQuiz.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.Core
{
    public class QuestionsController
    {
        GameDBContext gameDBContext = new GameDBContext();

        public async Task AddQuestion(int id,string questiontext, int amount)
        {
            Questions questions = new Questions()
            {
                Id = id,
                question_text = questiontext,
                amount = amount
            };
            await gameDBContext.Questions.AddAsync(questions);
            await gameDBContext.SaveChangesAsync();
        }

        public async Task Add4answear(int id, Answers one,Answers two,Answers treee, Answers four)
        {
            var qestin=await gameDBContext.Questions.FindAsync(id);

            if(qestin != null)
            {
                one.Id = qestin.Id;
                two.Id = qestin.Id;
                treee.Id = qestin.Id;
                four.Id = qestin.Id;
            }
        }

        public async Task UpdateQuestionsById(int id, string questiontext, int amount)
        {
            var question=await gameDBContext.Questions.FirstOrDefaultAsync(q=>q.Id == id);
            question.question_text= questiontext;
            question.amount= amount;
            await gameDBContext.SaveChangesAsync();
        }

        public async Task<List<Questions>> TekstNad300()
        {
            var question = await gameDBContext.Questions.Where(q => q.amount > 3000)
                                                  .ToListAsync();
            return question;
        }

        public async Task<List<Questions>> AllQuestionAndAnswer()
        {
            var question = await gameDBContext.Questions.Include(x => x.answers).ToListAsync();
            return question;
        }

        public async Task<Answers> OtgovorByAmout(int amount)
        {
            var question = await gameDBContext.Questions.Include(x => x.answers).FirstOrDefaultAsync(q => q.amount == amount);
            var answer = question.answers.FirstOrDefault(a => a.is_correct == true);
            return answer;
        }
    }
}
