﻿using MoneyQuiz.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.Core
{
    public class PlayersController
    {
        GameDBContext gameDBContext = new GameDBContext();
        public async Task AddPLayer(int id, string nAME, string eMAIL)
        {
            Players players = new Players()
            { 
                Id= id,
                name = nAME,
                email = eMAIL
            };
            await gameDBContext.Player.Add(players);
            await gameDBContext.SaveChangesAsync();
        }
    }
}
