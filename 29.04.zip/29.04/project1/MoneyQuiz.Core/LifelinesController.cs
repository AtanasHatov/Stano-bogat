﻿using Microsoft.EntityFrameworkCore;
using MoneyQuiz.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.Core
{
    public class LifelinesController
    {
        GameDBContext gameDBContext = new GameDBContext();

        public async Task RemoleveLifeLines(int id)
        {
            var lifelines=await gameDBContext.Lilines.FirstOrDefaultAsync(l => l.Id == id);
            gameDBContext.Lilines.Remove(lifelines);
            await gameDBContext.SaveChangesAsync();
        }
    }
}
