﻿namespace MoneyQuiz.ConsoleApp
{
    public class Class1
    {

    }
}
