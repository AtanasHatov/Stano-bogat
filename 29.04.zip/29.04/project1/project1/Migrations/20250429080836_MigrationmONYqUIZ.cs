﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MoneyQuiz.Data.Migrations
{
    /// <inheritdoc />
    public partial class MigrationmONYqUIZ : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "GameSessions",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    time = table.Column<int>(type: "int", nullable: false),
                    final_amount = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GameSessions", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Players",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    email = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Players", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Questions",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    question_text = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    amount = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Questions", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Player_games_session",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PayersID = table.Column<int>(type: "int", nullable: false),
                    SessionsID = table.Column<int>(type: "int", nullable: false),
                    game_SessionsId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Player_games_session", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Player_games_session_GameSessions_game_SessionsId",
                        column: x => x.game_SessionsId,
                        principalTable: "GameSessions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Player_games_session_Players_PayersID",
                        column: x => x.PayersID,
                        principalTable: "Players",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Answers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    answer_text = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    is_correct = table.Column<bool>(type: "bit", nullable: false),
                    QuestionsID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Answers", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Answers_Questions_QuestionsID",
                        column: x => x.QuestionsID,
                        principalTable: "Questions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Lilines",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Player_games_sessionID = table.Column<int>(type: "int", nullable: false),
                    type = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    useonqustionID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Lilines", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Lilines_Player_games_session_Player_games_sessionID",
                        column: x => x.Player_games_sessionID,
                        principalTable: "Player_games_session",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Lilines_Questions_useonqustionID",
                        column: x => x.useonqustionID,
                        principalTable: "Questions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Player_answers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    player_sessionId = table.Column<int>(type: "int", nullable: false),
                    player_Games_SessionId = table.Column<int>(type: "int", nullable: false),
                    AnswerID = table.Column<int>(type: "int", nullable: false),
                    answersId = table.Column<int>(type: "int", nullable: false),
                    is_correct = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Player_answers", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Player_answers_Answers_answersId",
                        column: x => x.answersId,
                        principalTable: "Answers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Player_answers_Player_games_session_player_Games_SessionId",
                        column: x => x.player_Games_SessionId,
                        principalTable: "Player_games_session",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Answers_QuestionsID",
                table: "Answers",
                column: "QuestionsID");

            migrationBuilder.CreateIndex(
                name: "IX_Lilines_Player_games_sessionID",
                table: "Lilines",
                column: "Player_games_sessionID");

            migrationBuilder.CreateIndex(
                name: "IX_Lilines_useonqustionID",
                table: "Lilines",
                column: "useonqustionID");

            migrationBuilder.CreateIndex(
                name: "IX_Player_answers_answersId",
                table: "Player_answers",
                column: "answersId");

            migrationBuilder.CreateIndex(
                name: "IX_Player_answers_player_Games_SessionId",
                table: "Player_answers",
                column: "player_Games_SessionId");

            migrationBuilder.CreateIndex(
                name: "IX_Player_games_session_game_SessionsId",
                table: "Player_games_session",
                column: "game_SessionsId");

            migrationBuilder.CreateIndex(
                name: "IX_Player_games_session_PayersID",
                table: "Player_games_session",
                column: "PayersID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Lilines");

            migrationBuilder.DropTable(
                name: "Player_answers");

            migrationBuilder.DropTable(
                name: "Answers");

            migrationBuilder.DropTable(
                name: "Player_games_session");

            migrationBuilder.DropTable(
                name: "Questions");

            migrationBuilder.DropTable(
                name: "GameSessions");

            migrationBuilder.DropTable(
                name: "Players");
        }
    }
}
