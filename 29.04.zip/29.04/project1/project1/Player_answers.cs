﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.Data
{
    public class Player_answers
    {
        [Key]
        public int Id { get; set; }
        [ForeignKey(nameof(Player_games_session))]
        public int player_sessionId { get; set; }
        public Player_games_session player_Games_Session { get; set; }
        [ForeignKey(nameof(Answers))]
        public int AnswerID { get; set; }
        public Answers answers { get; set; }
        [Required]
        public bool is_correct { get; set; }
    }
}
