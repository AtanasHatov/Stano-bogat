﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.Data
{
    public class Lifelines
    {
        [Key]
        public int Id { get; set; }
        [ForeignKey(nameof(Player_games_session))]
        public int Player_games_sessionID { get; set; }
        public Player_games_session player_Games_Session { get; set; }
        [Required]
        public string type { get; set; }
        [ForeignKey(nameof(Questions))]
        public int useonqustionID { get; set; }
        public Questions Questions { get; set; }
    }
}
