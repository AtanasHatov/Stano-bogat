﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.Data
{
    public class Answers
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string answer_text { get; set; }
        [Required]
        public bool is_correct { get; set; }
        [ForeignKey(nameof(Questions))]
        public int QuestionsID { get; set; }
        public Questions Questions { get; set; }
    }
}
