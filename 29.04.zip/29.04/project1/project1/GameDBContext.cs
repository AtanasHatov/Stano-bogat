﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace MoneyQuiz.Data
{
    public class GameDBContext : DbContext
    {
        public GameDBContext(DbContextOptions options) : base(options)
        {
        }

        public GameDBContext() : base()
        {
            
        }

        public DbSet<Answers> Answers { get; set; }
        public DbSet<Game_sessions> GameSessions { get; set; }
        public DbSet<Lifelines> Lilines { get; set; }
        public DbSet<Player_answers> Player_answers { get; set; }
        public DbSet<Player_games_session> Player_games_session { get; set; }
        public DbSet<Players> Players { get; set; }
        public DbSet<Questions> Questions { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source = STUDENT7; Integrated Security = True; Initial Catalog=Monyee; Connect Timeout = 30; Encrypt = True; Trust Server Certificate = True; Application Intent = ReadWrite; Multi Subnet Failover = False");
        }
    }
}
