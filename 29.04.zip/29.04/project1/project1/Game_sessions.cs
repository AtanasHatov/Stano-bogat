﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.Data
{
    public class Game_sessions
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public int time { get; set; }
        [Required]
        public int final_amount { get; set; }
    }
}
