﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.Data
{
    public class Player_games_session
    {
        [Key]
        public int Id { get; set; }
        [ForeignKey(nameof(Players))]
        public int PayersID { get; set; }
        public Players Players { get; set; }
        [ForeignKey(nameof(Game_sessions))]
        public int SessionsID { get; set; }
        public Game_sessions game_Sessions { get; set; }
    }
}
